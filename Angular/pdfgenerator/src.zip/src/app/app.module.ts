import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { NgpdfmakeuseComponent } from './ngpdfmakeuse/ngpdfmakeuse.component';

@NgModule({
  declarations: [
    AppComponent,
    NgpdfmakeuseComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
