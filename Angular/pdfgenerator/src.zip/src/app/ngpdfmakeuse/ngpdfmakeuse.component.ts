import { Component,OnInit} from '@angular/core';
// declare var pdfMake:any;
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
pdfMake.vfs = pdfFonts.pdfMake.vfs;
@Component({
  selector: 'app-ngpdfmakeuse',
  templateUrl: './ngpdfmakeuse.component.html',
  styleUrls: ['./ngpdfmakeuse.component.css']
})
export class NgpdfmakeuseComponent implements OnInit {
  dataURL: any = ''
  docDefinition: any = {};
  constructor() {}

  ngOnInit() {
    setTimeout(() => {
      var pdfDocGenerator = pdfMake.createPdf(this.docDefinition);
      
      pdfDocGenerator.getDataUrl((dataUrl) => {
        const targetElement = document.querySelector('#iframeContainer');
        const iframe = document.createElement('iframe');
        iframe.src = dataUrl;
        iframe.height = '850px';
        iframe.width = '100%'
        targetElement.appendChild(iframe);
      });
    }, 1000);

    this.toDataURL('../assets/images/Koala.jpeg', (dataURL) => {
      // do something with dataURL
      this.docDefinition = {
        // header: 'simple text',

        // footer: {
        //   columns: [
        //     'Left part',
        //     { text: 'Right part', alignment: 'right' }
        //   ]
        // },
        watermark: {text: 'katalysttech.com', color: 'blue', opacity: 0.1,  bold: true, italics: true},
        footer: function (currentPage, pageCount) {
          return currentPage.toString() + ' of ' + pageCount;
        },
        header: function (currentPage, pageCount, pageSize) {
          // you can apply any logic and return any valid pdfmake element

          return [{
              text: 'simple text',
              alignment: (currentPage % 2) ? 'left' : 'right'
            },
            {
              canvas: [{
                type: 'rect',
                x: 170,
                y: 32,
                w: pageSize.width - 170,
                h: 40
              }]
            }
          ]
        },
        background: 'simple text',
        info: {
          title: 'Title of file',
          author: 'rani more'
        },
        content: [{
            text: 'This is a header',
            style: 'header'
          },
          'No styling here, this is a standard paragraph',
          {
            text: 'Another text',
            style: 'anotherStyle'
          },
          {
            text: 'Multiple styles applied',
            style: ['header', 'anotherStyle']
          },

          'This paragraph fills full width, as there are no columns. Next paragraph however consists of three columns',
          {
            columns: [{
                // auto-sized columns have their widths based on their content
                width: 'auto',
                text: 'First column'
              },
              {
                // star-sized columns fill the remaining space
                // if there's more than one star-column, available width is divided equally
                width: '*',
                text: 'Second column'
              },
              {
                // fixed width
                width: 100,
                text: 'Third column'
              },
              {
                // % width
                width: '20%',
                text: 'Fourth column'
              },
              {
                stack: [
                  // second column consists of paragraphs
                  'paragraph A',
                  'paragraph B',
                  'these paragraphs will be rendered one below another inside the column'
                ],
                fontSize: 15
              }
            ],
            // optional space between columns
            columnGap: 10
          },
          'This paragraph goes below all columns and has full width',
          {
            width: 100,
            image: dataURL
            // this.toDataURL('../assets/images/Koala.jpeg')
            // this.imageToBase64('../assets/images/Koala.jpeg')
            // 'data:image/jpeg;base64,'+ 
          },
          {
            layout: 'lightHorizontalLines', // optional
            table: {
              // headers are automatically repeated if the table spans over multiple pages
              // you can declare how many rows should be treated as headers
              headerRows: 1,
              widths: ['*', 'auto', 100, '*'],

              body: [
                ['First', 'Second', 'Third', 'The last one'],
                ['Value 1', 'Value 2', 'Value 3', 'Value 4'],
                [{
                  text: 'Bold value',
                  bold: true
                }, 'Val 2', 'Val 3', 'Val 4']
              ]
            }
          },
          'Bulleted list example:',
          {
            // to treat a paragraph as a bulleted list, set an array of items under the ul key
            ul: [
              'Item 1',
              'Item 2',
              'Item 3',
              {
                text: 'Item 4',
                bold: true
              },
            ]
          },

          'Numbered list example:',
          {
            // for numbered lists set the ol key
            ol: [
              'Item 1',
              'Item 2',
              'Item 3'
            ]
          },
          // {
          //   toc: {
          //     // id: 'mainToc'  // optional
          //     title: {text: 'INDEX', style: 'header'}
          //   }
          // },
          // {
          //   text: 'This is a header',
          //   style: 'header',
          //   tocItem: true, // or tocItem: 'mainToc' if is used id in toc
          //   // or tocItem: ['mainToc', 'subToc'] for multiple tocs
          // }
          {
            text: 'Text on Portrait'
          },
          {
            text: 'Text on Landscape',
            pageOrientation: 'landscape',
            pageBreak: 'before'
          },
          {
            text: 'Text on Landscape 2',
            pageOrientation: 'portrait',
            pageBreak: 'after'
          },
          {
            text: 'Text on Portrait 2'
          },
        ],
        styles: {
          header: {
            fontSize: 22,
            bold: true
          },
          anotherStyle: {
            italics: true,
            alignment: 'right'
          }
        },
      };
    });
  }
  imageToBase64(url) {


    var img = new Image();
    img.setAttribute('crossOrigin', 'Anonymous');
    img.src = url;
    img.width = 40;
    img.height = 40;
    //  img.onload=function(){
    var canvas, ctx, dataURL, base64;
    canvas = document.createElement("canvas");
    ctx = canvas.getContext("2d");
    canvas.width = img.width;
    canvas.height = img.height;
    ctx.drawImage(img, 0, 0);
    dataURL = canvas.toDataURL("image/jpeg");

    // base64 = dataURL.replace(/^data:image\/jpeg;base64,/, "");

    return dataURL;
    //  }

  }
  toDataURL(src, callback) {

    var xhttp = new XMLHttpRequest();
    var self = this;
    xhttp.onload = event => {
      var fileReader = new FileReader();
      var myself = self;
      fileReader.onloadend = event => {
        myself.dataURL = fileReader.result;

        // return fileReader.result; 
        callback(fileReader.result);
      }
      fileReader.readAsDataURL(xhttp.response);
    };

    xhttp.responseType = 'blob';
    xhttp.open('GET', src, true);
    xhttp.send();
  }
  open() {
    pdfMake.createPdf(this.docDefinition).open();
  }
  download() {
    pdfMake.createPdf(this.docDefinition).download('demofile.pdf');
  }
  print() {
    pdfMake.createPdf(this.docDefinition).print();
  }
}
